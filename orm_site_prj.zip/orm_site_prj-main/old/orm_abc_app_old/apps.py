from django.apps import AppConfig


class OrmAbcAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'orm_abc_app'
